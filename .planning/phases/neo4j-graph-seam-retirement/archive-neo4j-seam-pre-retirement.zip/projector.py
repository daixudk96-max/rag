"""KG projection primitives for the formal runtime.

Provides DTOs and a GraphProjector that issues Cypher statements to
project entities, relations, and evidence links (anchored on span_id)
from the registry into Neo4j via the existing PropertyGraphIndex/Neo4j seam.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol
from uuid import UUID


# ---------------------------------------------------------------------------
# Projection DTOs (frozen, matching the verification graph_path Cypher shapes)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EntityProjection:
    entity_id: UUID
    entity_key: str
    entity_type: str | None
    canonical_name: str | None
    description: str | None = None  # GraphRAG-style entity description
    community_id: UUID | None = None  # GraphRAG-style community detection


@dataclass(frozen=True)
class RelationProjection:
    relation_id: UUID
    relation_type: str
    source_entity_id: UUID
    target_entity_id: UUID
    description: str | None = None  # GraphRAG-style relationship description


@dataclass(frozen=True)
class EvidenceLinkProjection:
    entity_id: UUID | None
    relation_id: UUID | None
    version_id: UUID
    span_id: UUID
    confidence_score: float | None

    def __post_init__(self) -> None:
        if self.entity_id is None and self.relation_id is None:
            raise ValueError("At least one of entity_id or relation_id must be set")


# ---------------------------------------------------------------------------
# GraphProjector -- issues Cypher via a neo4j Driver
# ---------------------------------------------------------------------------


class GraphProjector:
    """Projects KG primitives into Neo4j using the same Cypher shapes
    as verification/src/graph_path/projection.py but driven from the
    formal runtime's frozen DTOs.
    """

    def __init__(self, driver: Any) -> None:
        self._driver = driver

    def project_entity(self, entity: EntityProjection) -> None:
        with self._driver.session() as session:
            session.run(
                "MERGE (e:Entity {entity_id: $entity_id}) "
                "SET e.entity_key = $entity_key, "
                "e.entity_type = $entity_type, "
                "e.canonical_name = $canonical_name, "
                "e.description = $description, "
                "e.community_id = $community_id",
                entity_id=str(entity.entity_id),
                entity_key=entity.entity_key,
                entity_type=entity.entity_type,
                canonical_name=entity.canonical_name,
                description=entity.description,
                community_id=str(entity.community_id) if entity.community_id else None,
            ).consume()

    def project_relation(self, relation: RelationProjection) -> None:
        with self._driver.session() as session:
            session.run(
                "MATCH (s:Entity {entity_id: $source_entity_id}) "
                "MATCH (t:Entity {entity_id: $target_entity_id}) "
                "MERGE (s)-[r:RELATION {relation_id: $relation_id}]->(t) "
                "SET r.relation_type = $relation_type, "
                "r.description = $description",
                relation_id=str(relation.relation_id),
                relation_type=relation.relation_type,
                source_entity_id=str(relation.source_entity_id),
                target_entity_id=str(relation.target_entity_id),
                description=relation.description,
            ).consume()

    def project_evidence_link(self, link: EvidenceLinkProjection) -> None:
        with self._driver.session() as session:
            if link.entity_id is not None:
                session.run(
                    "MATCH (e:Entity {entity_id: $entity_id}) "
                    "MERGE (v:Version {version_id: $version_id}) "
                    "MERGE (e)-[r:SUPPORTED_BY {span_id: $span_id}]->(v) "
                    "SET r.confidence_score = $confidence_score",
                    entity_id=str(link.entity_id),
                    version_id=str(link.version_id),
                    span_id=str(link.span_id),
                    confidence_score=link.confidence_score,
                ).consume()
            elif link.relation_id is not None:
                session.run(
                    "MATCH ()-[r:RELATION {relation_id: $relation_id}]->() "
                    "MERGE (v:Version {version_id: $version_id}) "
                    "MERGE (r)-[s:SUPPORTED_BY {span_id: $span_id}]->(v) "
                    "SET s.confidence_score = $confidence_score",
                    relation_id=str(link.relation_id),
                    version_id=str(link.version_id),
                    span_id=str(link.span_id),
                    confidence_score=link.confidence_score,
                ).consume()


# ---------------------------------------------------------------------------
# High-level orchestration: project all KG data for a version
# ---------------------------------------------------------------------------


class RegistryReader(Protocol):
    """Subset of RegistryWriter needed for read operations."""

    def query_entities(self) -> list[dict[str, Any]]: ...
    def query_relations(self) -> list[dict[str, Any]]: ...
    def query_evidence_links_by_version(self, version_id: UUID) -> list[dict[str, Any]]: ...


def project_version_to_graph(
    registry: RegistryReader,
    projector: GraphProjector,
    *,
    version_id: UUID,
) -> None:
    """Read all KG data for *version_id* from *registry* and project into Neo4j.

    Projection order: entities first (relations MATCH on them), then relations,
    then evidence links (which reference both entities and relations).
    """
    # 1. Project entities
    for row in registry.query_entities():
        projector.project_entity(
            EntityProjection(
                entity_id=row["entity_id"],
                entity_key=row["entity_key"],
                entity_type=row.get("entity_type"),
                canonical_name=row.get("canonical_name"),
                description=row.get("description"),  # GraphRAG-style
                community_id=row.get("community_id"),  # GraphRAG-style
            )
        )

    # 2. Project relations
    for row in registry.query_relations():
        projector.project_relation(
            RelationProjection(
                relation_id=row["relation_id"],
                relation_type=row["relation_type"],
                source_entity_id=row["source_entity_id"],
                target_entity_id=row["target_entity_id"],
                description=row.get("description"),  # GraphRAG-style
            )
        )

    # 3. Project evidence links (span_id-anchored)
    for row in registry.query_evidence_links_by_version(version_id):
        projector.project_evidence_link(
            EvidenceLinkProjection(
                entity_id=row.get("entity_id"),
                relation_id=row.get("relation_id"),
                version_id=row["version_id"],
                span_id=row["span_id"],
                confidence_score=row.get("confidence_score"),
            )
        )
