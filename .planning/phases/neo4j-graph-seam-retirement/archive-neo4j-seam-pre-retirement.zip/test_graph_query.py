"""Tests for Phase 6 Slice 1: Graph retrieval path.

These tests verify:
1. retrieve_graph_hits queries entity neighbors via Neo4j driver
2. Query entrypoint accepts mode='graph' and routes to graph runtime
3. Classifier auto-routes obvious graph/concept queries to graph mode
4. Graph hits are mapped to QueryHit with correct metadata
5. Edge cases: empty graph, missing entity, driver None
"""
from __future__ import annotations

import uuid
from unittest.mock import MagicMock, patch

import pytest

from llamaindex_runtime.entrypoints import QueryHit, QueryResult, query


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_mock_driver_with_neighbors(entity_id: uuid.UUID, neighbors: list[dict]) -> tuple[MagicMock, MagicMock]:
    """Return (driver, session) where session.run returns neighbor data."""
    driver = MagicMock()
    session = MagicMock()
    result = MagicMock()
    result.data.return_value = [
        {
            "entity_id": str(n["entity_id"]),
            "entity_key": n["entity_key"],
            "relation_type": n["relation_type"],
            "canonical_name": n.get("canonical_name"),
            "entity_type": n.get("entity_type"),
        }
        for n in neighbors
    ]
    session.run.return_value = result
    session.__enter__ = MagicMock(return_value=session)
    session.__exit__ = MagicMock(return_value=False)
    driver.session.return_value = session
    return driver, session


# ===========================================================================
# UNIT TESTS -- retrieve_graph_hits function (mocked Neo4j driver)
# ===========================================================================


class TestRetrieveGraphHitsContract:
    """retrieve_graph_hits queries entity neighbors and returns QueryHit list."""

    def test_function_exists(self) -> None:
        """Graph runtime must expose retrieve_graph_hits function."""
        from llamaindex_runtime.graph import retrieve_graph_hits

        assert callable(retrieve_graph_hits)

    def test_queries_entity_neighbors_by_id(self) -> None:
        """retrieve_graph_hits should query neighbors via driver."""
        from llamaindex_runtime.graph import retrieve_graph_hits

        entity_id = uuid.uuid4()
        neighbor_id = uuid.uuid4()
        driver, session = _make_mock_driver_with_neighbors(
            entity_id,
            [
                {
                    "entity_id": neighbor_id,
                    "entity_key": "concept:aqi",
                    "relation_type": "affects",
                    "canonical_name": "AQI",
                    "entity_type": "concept",
                }
            ]
        )

        hits = retrieve_graph_hits(
            driver=driver,
            entity_id=entity_id,
            depth=1,
        )

        session.run.assert_called_once()
        assert len(hits) == 1
        assert isinstance(hits[0], QueryHit)

    def test_maps_neighbor_to_query_hit_with_metadata(self) -> None:
        """Neighbor data should be mapped to QueryHit with entity metadata."""
        from llamaindex_runtime.graph import retrieve_graph_hits

        entity_id = uuid.uuid4()
        neighbor_id = uuid.uuid4()
        driver, _session = _make_mock_driver_with_neighbors(
            entity_id,
            [
                {
                    "entity_id": neighbor_id,
                    "entity_key": "concept:pm25",
                    "relation_type": "causes",
                    "canonical_name": "PM2.5",
                    "entity_type": "concept",
                }
            ]
        )

        hits = retrieve_graph_hits(
            driver=driver,
            entity_id=entity_id,
            depth=1,
        )

        assert hits[0].text == "PM2.5"  # canonical_name as text
        assert hits[0].score is None  # graph queries have no similarity score
        assert hits[0].metadata["entity_id"] == neighbor_id
        assert hits[0].metadata["entity_key"] == "concept:pm25"
        assert hits[0].metadata["relation_type"] == "causes"
        assert hits[0].metadata["entity_type"] == "concept"

    def test_empty_neighbors_returns_empty_hits(self) -> None:
        """Entity with no neighbors should return empty hit list."""
        from llamaindex_runtime.graph import retrieve_graph_hits

        entity_id = uuid.uuid4()
        driver, _session = _make_mock_driver_with_neighbors(entity_id, [])

        hits = retrieve_graph_hits(
            driver=driver,
            entity_id=entity_id,
            depth=1,
        )

        assert hits == []
        assert isinstance(hits, list)

    def test_depth_parameter_passed_to_cypher(self) -> None:
        """Depth parameter should control neighbor traversal depth."""
        from llamaindex_runtime.graph import retrieve_graph_hits

        entity_id = uuid.uuid4()
        driver, session = _make_mock_driver_with_neighbors(entity_id, [])

        retrieve_graph_hits(
            driver=driver,
            entity_id=entity_id,
            depth=2,
        )

        # Verify depth is used in the Cypher query
        cypher = session.run.call_args[0][0]
        assert "2" in cypher or "depth" in cypher.lower()

    def test_requires_driver(self) -> None:
        """retrieve_graph_hits should require driver parameter."""
        from llamaindex_runtime.graph import retrieve_graph_hits

        with pytest.raises(ValueError, match="driver"):
            retrieve_graph_hits(
                driver=None,
                entity_id=uuid.uuid4(),
                depth=1,
            )

    def test_requires_entity_id(self) -> None:
        """retrieve_graph_hits should require entity_id parameter."""
        from llamaindex_runtime.graph import retrieve_graph_hits

        driver = MagicMock()
        with pytest.raises(ValueError, match="entity_id"):
            retrieve_graph_hits(
                driver=driver,
                entity_id=None,
                depth=1,
            )


# ===========================================================================
# UNIT TESTS -- Unified query entrypoint with mode='graph'
# ===========================================================================


class TestQueryEntrypointGraphMode:
    """query() should accept mode='graph' and route to graph runtime."""

    def test_graph_mode_accepted(self) -> None:
        """Graph mode should be a valid mode option (no ValueError on mode)."""
        # Graph mode is now supported - should raise ValueError on missing driver/entity_id
        with pytest.raises(ValueError, match="driver"):
            query(
                source_path="/tmp/fake.pdf",
                query_text="find concepts related to PM2.5",
                mode="graph",
                driver=None,
                entity_id=uuid.uuid4(),
            )

    @patch("llamaindex_runtime.entrypoints._query.retrieve_graph_hits")
    def test_graph_mode_calls_graph_runtime(self, mock_graph) -> None:
        """mode='graph' should call retrieve_graph_hits."""
        entity_id = uuid.uuid4()
        neighbor_id = uuid.uuid4()
        mock_graph.return_value = [
            QueryHit(
                text="AQI",
                score=None,
                metadata={
                    "entity_id": neighbor_id,
                    "entity_key": "concept:aqi",
                    "relation_type": "affects",
                }
            )
        ]

        driver = MagicMock()
        result = query(
            source_path="/tmp/test.pdf",
            query_text="concepts related to PM2.5",
            mode="graph",
            driver=driver,
            entity_id=entity_id,
            depth=1,
        )

        mock_graph.assert_called_once_with(
            driver=driver,
            entity_id=entity_id,
            depth=1,
        )
        assert result.mode == "graph"
        assert len(result.hits) == 1
        assert result.hits[0].text == "AQI"

    def test_graph_mode_requires_driver(self) -> None:
        """Graph mode should require driver parameter."""
        with pytest.raises(ValueError, match="driver"):
            query(
                source_path="/tmp/test.pdf",
                query_text="graph query",
                mode="graph",
                driver=None,
                entity_id=uuid.uuid4(),
            )

    def test_graph_mode_requires_entity_id(self) -> None:
        """Graph mode should require entity_id parameter."""
        with pytest.raises(ValueError, match="entity_id"):
            query(
                source_path="/tmp/test.pdf",
                query_text="graph query",
                mode="graph",
                driver=MagicMock(),
                entity_id=None,
            )


# ===========================================================================
# UNIT TESTS -- Query classifier auto-routing to graph mode
# ===========================================================================


class TestQueryClassifierGraphRouting:
    """classify_query should auto-route obvious graph/concept queries."""

    def test_concept_query_routes_to_graph(self) -> None:
        """Queries asking for concepts should route to graph."""
        from llamaindex_runtime.entrypoints.classifier import classify_query

        # This test will fail because classifier doesn't support graph mode yet
        result = classify_query("find concepts related to PM2.5")
        # Currently returns "vector" but should return "graph"
        assert result == "graph"

    def test_entity_query_routes_to_graph(self) -> None:
        """Queries asking for entities should route to graph."""
        from llamaindex_runtime.entrypoints.classifier import classify_query

        result = classify_query("what entities are connected to AQI")
        assert result == "graph"

    def test_relation_query_routes_to_graph(self) -> None:
        """Queries explicitly asking for graph relations should route to graph."""
        from llamaindex_runtime.entrypoints.classifier import classify_query

        # More explicit graph query - mentioning "connected entities"
        result = classify_query("show me connected entities related to pollutants")
        assert result == "graph"

    def test_knowledge_graph_query_routes_to_graph(self) -> None:
        """Queries mentioning knowledge graph should route to graph."""
        from llamaindex_runtime.entrypoints.classifier import classify_query

        result = classify_query("search the knowledge graph for PM2.5")
        assert result == "graph"

    def test_natural_language_query_stays_vector(self) -> None:
        """Regular natural language queries should still route to vector."""
        from llamaindex_runtime.entrypoints.classifier import classify_query

        result = classify_query("what is the impact of air pollution on health")
        assert result == "vector"  # not graph

    def test_short_code_query_stays_keyword(self) -> None:
        """Short code-like queries should still route to keyword."""
        from llamaindex_runtime.entrypoints.classifier import classify_query

        result = classify_query("PM2.5-AQI")
        assert result == "keyword"  # not graph


# ===========================================================================
# UNIT TESTS -- QueryResult supports graph mode
# ===========================================================================


class TestQueryResultGraphMode:
    """QueryResult should support graph in its mode Literal."""

    def test_graph_mode_in_valid_modes(self) -> None:
        """QueryResult._VALID_MODES should include 'graph'."""
        # This will fail because QueryResult doesn't include graph yet
        result = QueryResult(
            mode="graph",
            hits=(),
            source_path="/tmp/doc.pdf",
            query="graph query",
        )
        assert result.mode == "graph"

    def test_query_result_frozen_with_graph_mode(self) -> None:
        """QueryResult should be frozen even with graph mode."""
        result = QueryResult(
            mode="graph",
            hits=(),
            source_path="/tmp/doc.pdf",
            query="test",
        )
        with pytest.raises(AttributeError):
            result.mode = "vector"  # type: ignore[misc]