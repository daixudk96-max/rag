"""Tests for P4 KG Enhancement Slice: GraphRAG-style model enrichments.

These tests verify:
1. Entity has description and community_id fields (GraphRAG-style)
2. Relation has description field (GraphRAG-style)
3. These fields are optional (nullable) to preserve backward compatibility
4. PostgresRegistryWriter correctly persists enriched models
5. GraphProjector correctly projects enriched fields into Neo4j
6. Evidence links backbone (span_id anchored) is preserved unchanged

This slice ONLY enriches the models - no LightRAG status, no EvidenceNet evidence_id, no KAG solver.
"""
from __future__ import annotations

import uuid
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from okf._e2a_pipeline_testkit import _FakeReconciler


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_rich_pdf(pdf_path: Path, text_body: str = "default body") -> None:
    from PIL import Image, ImageDraw

    image = Image.new("RGB", (1200, 1600), "white")
    draw = ImageDraw.Draw(image)
    draw.text((80, 80), "Formal Runtime Heading", fill="black")
    draw.text((80, 180), text_body, fill="black")
    draw.text((80, 260), "Second paragraph for the formal runtime live ingestion test.", fill="black")
    image.save(pdf_path, "PDF")


def _make_mock_driver() -> tuple[MagicMock, MagicMock]:
    """Return (driver, session) where session.run is tracked."""
    driver = MagicMock()
    session = MagicMock()
    result = MagicMock()
    result.consume.return_value = None
    session.run.return_value = result
    session.__enter__ = MagicMock(return_value=session)
    session.__exit__ = MagicMock(return_value=False)
    driver.session.return_value = session
    return driver, session


# ===========================================================================
# UNIT TESTS -- Entity enrichment (GraphRAG-style)
# ===========================================================================


class TestEntityGraphRAGEnrichment:
    """Entity model enriched with GraphRAG-style fields: description, community_id."""

    def test_entity_has_description_field(self) -> None:
        """Entity must have a description field for GraphRAG-style entity descriptions."""
        from llamaindex_runtime.registry.contracts import Entity

        entity = Entity(
            entity_id=uuid.uuid4(),
            entity_key="concept:pm25",
            entity_type="concept",
            canonical_name="PM2.5",
            description="Fine particulate matter with diameter less than 2.5 micrometers",
        )
        assert hasattr(entity, "description")
        assert entity.description == "Fine particulate matter with diameter less than 2.5 micrometers"

    def test_entity_has_community_id_field(self) -> None:
        """Entity must have a community_id field for GraphRAG-style community detection."""
        from llamaindex_runtime.registry.contracts import Entity

        community_id = uuid.uuid4()
        entity = Entity(
            entity_id=uuid.uuid4(),
            entity_key="concept:pm25",
            entity_type="concept",
            canonical_name="PM2.5",
            community_id=community_id,
        )
        assert hasattr(entity, "community_id")
        assert entity.community_id == community_id

    def test_entity_description_optional_can_be_none(self) -> None:
        """Entity description must be optional (nullable) for backward compatibility."""
        from llamaindex_runtime.registry.contracts import Entity

        entity = Entity(
            entity_id=uuid.uuid4(),
            entity_key="concept:pm25",
            entity_type="concept",
            canonical_name="PM2.5",
            description=None,
        )
        assert entity.description is None

    def test_entity_community_id_optional_can_be_none(self) -> None:
        """Entity community_id must be optional (nullable) - not all entities belong to communities."""
        from llamaindex_runtime.registry.contracts import Entity

        entity = Entity(
            entity_id=uuid.uuid4(),
            entity_key="concept:pm25",
            entity_type="concept",
            canonical_name="PM2.5",
            community_id=None,
        )
        assert entity.community_id is None

    def test_entity_frozen_with_new_fields(self) -> None:
        """Entity must remain frozen after adding GraphRAG fields."""
        from llamaindex_runtime.registry.contracts import Entity

        entity = Entity(
            entity_id=uuid.uuid4(),
            entity_key="concept:pm25",
            entity_type="concept",
            canonical_name="PM2.5",
            description="Test description",
            community_id=uuid.uuid4(),
        )
        with pytest.raises(AttributeError):
            entity.description = "modified"  # type: ignore[misc]
        with pytest.raises(AttributeError):
            entity.community_id = uuid.uuid4()  # type: ignore[misc]


# ===========================================================================
# UNIT TESTS -- Relation enrichment (GraphRAG-style)
# ===========================================================================


class TestRelationGraphRAGEnrichment:
    """Relation model enriched with GraphRAG-style field: description."""

    def test_relation_has_description_field(self) -> None:
        """Relation must have a description field for GraphRAG-style relationship descriptions."""
        from llamaindex_runtime.registry.contracts import Relation

        relation = Relation(
            relation_id=uuid.uuid4(),
            relation_key="pm25-affects-aqi",
            relation_type="affects",
            source_entity_id=uuid.uuid4(),
            target_entity_id=uuid.uuid4(),
            description="PM2.5 concentration directly impacts Air Quality Index values",
        )
        assert hasattr(relation, "description")
        assert relation.description == "PM2.5 concentration directly impacts Air Quality Index values"

    def test_relation_description_optional_can_be_none(self) -> None:
        """Relation description must be optional (nullable) for backward compatibility."""
        from llamaindex_runtime.registry.contracts import Relation

        relation = Relation(
            relation_id=uuid.uuid4(),
            relation_key="pm25-affects-aqi",
            relation_type="affects",
            source_entity_id=uuid.uuid4(),
            target_entity_id=uuid.uuid4(),
            description=None,
        )
        assert relation.description is None

    def test_relation_frozen_with_new_field(self) -> None:
        """Relation must remain frozen after adding GraphRAG field."""
        from llamaindex_runtime.registry.contracts import Relation

        relation = Relation(
            relation_id=uuid.uuid4(),
            relation_key="pm25-affects-aqi",
            relation_type="affects",
            source_entity_id=uuid.uuid4(),
            target_entity_id=uuid.uuid4(),
            description="Test description",
        )
        with pytest.raises(AttributeError):
            relation.description = "modified"  # type: ignore[misc]


# ===========================================================================
# UNIT TESTS -- EntityProjection enrichment (GraphRAG-style)
# ===========================================================================


class TestEntityProjectionGraphRAGEnrichment:
    """EntityProjection enriched with GraphRAG-style fields for Neo4j projection."""

    def test_entity_projection_has_description_field(self) -> None:
        """EntityProjection must have description field for GraphRAG-style projection."""
        from llamaindex_runtime.graph.projector import EntityProjection

        projection = EntityProjection(
            entity_id=uuid.uuid4(),
            entity_key="concept:pm25",
            entity_type="concept",
            canonical_name="PM2.5",
            description="Fine particulate matter",
        )
        assert hasattr(projection, "description")
        assert projection.description == "Fine particulate matter"

    def test_entity_projection_has_community_id_field(self) -> None:
        """EntityProjection must have community_id field for GraphRAG-style projection."""
        from llamaindex_runtime.graph.projector import EntityProjection

        community_id = uuid.uuid4()
        projection = EntityProjection(
            entity_id=uuid.uuid4(),
            entity_key="concept:pm25",
            entity_type="concept",
            canonical_name="PM2.5",
            community_id=community_id,
        )
        assert hasattr(projection, "community_id")
        assert projection.community_id == community_id

    def test_entity_projection_optional_fields_can_be_none(self) -> None:
        """EntityProjection new fields must be optional."""
        from llamaindex_runtime.graph.projector import EntityProjection

        projection = EntityProjection(
            entity_id=uuid.uuid4(),
            entity_key="concept:pm25",
            entity_type="concept",
            canonical_name="PM2.5",
            description=None,
            community_id=None,
        )
        assert projection.description is None
        assert projection.community_id is None


# ===========================================================================
# UNIT TESTS -- RelationProjection enrichment (GraphRAG-style)
# ===========================================================================


class TestRelationProjectionGraphRAGEnrichment:
    """RelationProjection enriched with GraphRAG-style field for Neo4j projection."""

    def test_relation_projection_has_description_field(self) -> None:
        """RelationProjection must have description field for GraphRAG-style projection."""
        from llamaindex_runtime.graph.projector import RelationProjection

        projection = RelationProjection(
            relation_id=uuid.uuid4(),
            relation_type="affects",
            source_entity_id=uuid.uuid4(),
            target_entity_id=uuid.uuid4(),
            description="PM2.5 affects AQI",
        )
        assert hasattr(projection, "description")
        assert projection.description == "PM2.5 affects AQI"

    def test_relation_projection_description_optional_can_be_none(self) -> None:
        """RelationProjection description must be optional."""
        from llamaindex_runtime.graph.projector import RelationProjection

        projection = RelationProjection(
            relation_id=uuid.uuid4(),
            relation_type="affects",
            source_entity_id=uuid.uuid4(),
            target_entity_id=uuid.uuid4(),
            description=None,
        )
        assert projection.description is None


# ===========================================================================
# UNIT TESTS -- GraphProjector with enriched fields
# ===========================================================================


class TestGraphProjectorEnrichedProjection:
    """GraphProjector must correctly project enriched Entity/Relation fields."""

    def test_project_entity_with_description(self) -> None:
        """GraphProjector must include description in Cypher when projecting entity."""
        from llamaindex_runtime.graph.projector import EntityProjection, GraphProjector

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        entity_id = uuid.uuid4()
        projector.project_entity(
            EntityProjection(
                entity_id=entity_id,
                entity_key="concept:pm25",
                entity_type="concept",
                canonical_name="PM2.5",
                description="Fine particulate matter",
            )
        )

        session.run.assert_called_once()
        cypher, kwargs = session.run.call_args[0][0], session.run.call_args[1]
        assert "description" in cypher or "description" in kwargs
        assert kwargs.get("description") == "Fine particulate matter"

    def test_project_entity_with_community_id(self) -> None:
        """GraphProjector must include community_id in Cypher when projecting entity."""
        from llamaindex_runtime.graph.projector import EntityProjection, GraphProjector

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        entity_id = uuid.uuid4()
        community_id = uuid.uuid4()
        projector.project_entity(
            EntityProjection(
                entity_id=entity_id,
                entity_key="concept:pm25",
                entity_type="concept",
                canonical_name="PM2.5",
                community_id=community_id,
            )
        )

        session.run.assert_called_once()
        cypher, kwargs = session.run.call_args[0][0], session.run.call_args[1]
        assert "community_id" in cypher or "community_id" in kwargs
        assert kwargs.get("community_id") == str(community_id)

    def test_project_relation_with_description(self) -> None:
        """GraphProjector must include description in Cypher when projecting relation."""
        from llamaindex_runtime.graph.projector import GraphProjector, RelationProjection

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        src = uuid.uuid4()
        tgt = uuid.uuid4()
        rid = uuid.uuid4()
        projector.project_relation(
            RelationProjection(
                relation_id=rid,
                relation_type="affects",
                source_entity_id=src,
                target_entity_id=tgt,
                description="PM2.5 directly impacts AQI",
            )
        )

        session.run.assert_called_once()
        cypher, kwargs = session.run.call_args[0][0], session.run.call_args[1]
        assert "description" in cypher or "description" in kwargs
        assert kwargs.get("description") == "PM2.5 directly impacts AQI"


# ===========================================================================
# LIVE TESTS -- Database persistence with enriched fields
# ===========================================================================


class TestLiveKGEnrichedPersistence:
    """Live tests for KG persistence with GraphRAG-style enriched fields."""

    def _ingest_and_get_registry(
        self,
        live_db_connection,
        tmp_path: Path,
        title: str = "KG enriched test",
    ) -> tuple:
        """Helper: ingest a PDF and return (registry, version_id, span_ids)."""
        from llamaindex_runtime.ingestion import IngestionPipeline
        from llamaindex_runtime.registry.postgres_adapter import PostgresRegistryWriter

        sample_pdf = tmp_path / f"{title.replace(' ', '-')}.pdf"
        _build_rich_pdf(sample_pdf)

        registry = PostgresRegistryWriter(live_db_connection)
        pipeline = IngestionPipeline(
            registry=registry,
            bundle_root=tmp_path,
            connection_factory=lambda: live_db_connection,
            reconciler=_FakeReconciler(),
        )
        result = pipeline.ingest(sample_pdf, title=title)

        spans = registry.query_spans_by_version(result.version_id)
        return registry, result.version_id, spans

    def test_write_entity_with_description(
        self, tmp_path: Path, live_db_connection, live_applied_schema, clean_live_db
    ) -> None:
        """write_entities must persist entity with description field."""
        registry, version_id, spans = self._ingest_and_get_registry(live_db_connection, tmp_path, "Entity with desc")

        entity_id = uuid.uuid4()
        registry.write_entities(
            entities=[
                {
                    "entity_id": entity_id,
                    "entity_key": "concept:pm25",
                    "entity_type": "concept",
                    "canonical_name": "PM2.5",
                    "description": "Fine particulate matter pollution",
                }
            ]
        )

        persisted = registry.query_entities()
        match = [e for e in persisted if e["entity_id"] == entity_id]
        assert len(match) == 1
        assert match[0]["description"] == "Fine particulate matter pollution"

    def test_write_entity_with_community_id(
        self, tmp_path: Path, live_db_connection, live_applied_schema, clean_live_db
    ) -> None:
        """write_entities must persist entity with community_id field."""
        registry, version_id, spans = self._ingest_and_get_registry(live_db_connection, tmp_path, "Entity with community")

        entity_id = uuid.uuid4()
        community_id = uuid.uuid4()
        registry.write_entities(
            entities=[
                {
                    "entity_id": entity_id,
                    "entity_key": "concept:pm25",
                    "entity_type": "concept",
                    "canonical_name": "PM2.5",
                    "community_id": community_id,
                }
            ]
        )

        persisted = registry.query_entities()
        match = [e for e in persisted if e["entity_id"] == entity_id]
        assert len(match) == 1
        assert match[0]["community_id"] == community_id

    def test_write_relation_with_description(
        self, tmp_path: Path, live_db_connection, live_applied_schema, clean_live_db
    ) -> None:
        """write_relations must persist relation with description field."""
        registry, version_id, spans = self._ingest_and_get_registry(live_db_connection, tmp_path, "Relation with desc")

        e1 = uuid.uuid4()
        e2 = uuid.uuid4()
        rel_id = uuid.uuid4()
        registry.write_entities(
            entities=[
                {"entity_id": e1, "entity_key": "concept:pm25", "entity_type": "concept", "canonical_name": "PM2.5"},
                {"entity_id": e2, "entity_key": "concept:aqi", "entity_type": "concept", "canonical_name": "AQI"},
            ]
        )
        registry.write_relations(
            relations=[
                {
                    "relation_id": rel_id,
                    "relation_key": "pm25-affects-aqi",
                    "relation_type": "affects",
                    "source_entity_id": e1,
                    "target_entity_id": e2,
                    "description": "PM2.5 levels directly influence AQI calculations",
                }
            ]
        )

        persisted = registry.query_relations()
        match = [r for r in persisted if r["relation_id"] == rel_id]
        assert len(match) == 1
        assert match[0]["description"] == "PM2.5 levels directly influence AQI calculations"

    def test_entity_null_enriched_fields_persisted(
        self, tmp_path: Path, live_db_connection, live_applied_schema, clean_live_db
    ) -> None:
        """Entity with null description and community_id must be persisted correctly."""
        registry, version_id, spans = self._ingest_and_get_registry(live_db_connection, tmp_path, "Entity null enriched")

        entity_id = uuid.uuid4()
        registry.write_entities(
            entities=[
                {
                    "entity_id": entity_id,
                    "entity_key": "concept:null_enriched",
                    "entity_type": "concept",
                    "canonical_name": "NullEnriched",
                    "description": None,
                    "community_id": None,
                }
            ]
        )

        persisted = registry.query_entities()
        match = [e for e in persisted if e["entity_id"] == entity_id]
        assert len(match) == 1
        assert match[0]["description"] is None
        assert match[0]["community_id"] is None

    def test_relation_null_description_persisted(
        self, tmp_path: Path, live_db_connection, live_applied_schema, clean_live_db
    ) -> None:
        """Relation with null description must be persisted correctly."""
        registry, version_id, spans = self._ingest_and_get_registry(live_db_connection, tmp_path, "Relation null desc")

        e1 = uuid.uuid4()
        e2 = uuid.uuid4()
        rel_id = uuid.uuid4()
        registry.write_entities(
            entities=[
                {"entity_id": e1, "entity_key": "concept:a", "entity_type": "concept", "canonical_name": "A"},
                {"entity_id": e2, "entity_key": "concept:b", "entity_type": "concept", "canonical_name": "B"},
            ]
        )
        registry.write_relations(
            relations=[
                {
                    "relation_id": rel_id,
                    "relation_key": "a-relates-b",
                    "relation_type": "relates_to",
                    "source_entity_id": e1,
                    "target_entity_id": e2,
                    "description": None,
                }
            ]
        )

        persisted = registry.query_relations()
        match = [r for r in persisted if r["relation_id"] == rel_id]
        assert len(match) == 1
        assert match[0]["description"] is None


# ===========================================================================
# UNIT TESTS -- Backward compatibility preserved
# ===========================================================================


class TestBackwardCompatibility:
    """Existing functionality must remain unchanged after enrichment."""

    def test_entity_without_enriched_fields_still_works(self) -> None:
        """Entity created without description/community_id must still be valid."""
        from llamaindex_runtime.registry.contracts import Entity

        entity = Entity(
            entity_id=uuid.uuid4(),
            entity_key="concept:backward_compat",
            entity_type="concept",
            canonical_name="BackwardCompat",
        )
        assert entity.entity_key == "concept:backward_compat"
        # New fields should default to None
        assert entity.description is None
        assert entity.community_id is None

    def test_relation_without_description_still_works(self) -> None:
        """Relation created without description must still be valid."""
        from llamaindex_runtime.registry.contracts import Relation

        relation = Relation(
            relation_id=uuid.uuid4(),
            relation_key="backward-compat-rel",
            relation_type="relates_to",
            source_entity_id=uuid.uuid4(),
            target_entity_id=uuid.uuid4(),
        )
        assert relation.relation_key == "backward-compat-rel"
        # New field should default to None
        assert relation.description is None

    def test_evidence_link_unchanged(self) -> None:
        """EvidenceLink must remain unchanged - span_id backbone preserved."""
        from llamaindex_runtime.registry.contracts import EvidenceLink

        link = EvidenceLink(
            evidence_link_id=uuid.uuid4(),
            version_id=uuid.uuid4(),
            entity_id=uuid.uuid4(),
            relation_id=None,
            span_id=uuid.uuid4(),
            source_kind="ner",
            confidence_score=0.9,
        )
        # EvidenceLink should NOT have new fields
        assert hasattr(link, "span_id")
        assert not hasattr(link, "description"), "EvidenceLink must not be enriched in this slice"
        assert not hasattr(link, "community_id"), "EvidenceLink must not be enriched in this slice"