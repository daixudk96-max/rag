from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from llamaindex_runtime.integration import load_neo4j_property_graph_store_class, load_property_graph_index_class

if TYPE_CHECKING:
    from llamaindex_runtime.graph.projector import GraphProjector


@dataclass(frozen=True)
class GraphRuntimeSeam:
    property_graph_index_class: type[Any]
    graph_store_class: type[Any]

    def create_projector(self, driver: Any) -> GraphProjector:
        from llamaindex_runtime.graph.projector import GraphProjector

        return GraphProjector(driver)


def create_graph_runtime_seam() -> GraphRuntimeSeam:
    return GraphRuntimeSeam(
        property_graph_index_class=load_property_graph_index_class(),
        graph_store_class=load_neo4j_property_graph_store_class(),
    )
