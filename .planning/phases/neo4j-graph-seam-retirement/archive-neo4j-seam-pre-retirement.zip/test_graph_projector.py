"""Tests for Phase 5 Slice 2: KG projection primitives.

These tests verify:
1. Projection DTOs (EntityProjection, RelationProjection, EvidenceLinkProjection)
   are frozen dataclasses with correct fields
2. GraphProjector issues correct Cypher statements for entities, relations,
   and evidence links
3. Evidence binding is preserved via span_id through the projection
4. project_version_to_graph reads from a RegistryWriter and projects all
   KG data for a given version into Neo4j
5. Edge cases: null optional fields, empty registry, evidence links on
   both entities and relations
"""
from __future__ import annotations

import uuid
from unittest.mock import MagicMock

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_mock_driver() -> tuple[MagicMock, MagicMock]:
    """Return (driver, session) where session.run is tracked."""
    driver = MagicMock()
    session = MagicMock()
    result = MagicMock()
    result.consume.return_value = None
    session.run.return_value = result
    session.__enter__ = MagicMock(return_value=session)
    session.__exit__ = MagicMock(return_value=False)
    driver.session.return_value = session
    return driver, session


# ===========================================================================
# UNIT TESTS -- Projection DTOs (no database required)
# ===========================================================================


class TestEntityProjectionContract:
    """EntityProjection frozen dataclass: required and optional fields, immutability."""

    def test_frozen_dataclass(self) -> None:
        from llamaindex_runtime.graph.projector import EntityProjection

        ep = EntityProjection(
            entity_id=uuid.uuid4(),
            entity_key="concept:pm25",
            entity_type="concept",
            canonical_name="PM2.5",
        )
        with pytest.raises(AttributeError):
            ep.entity_key = "modified"  # type: ignore[misc]

    def test_required_fields(self) -> None:
        from llamaindex_runtime.graph.projector import EntityProjection

        eid = uuid.uuid4()
        ep = EntityProjection(
            entity_id=eid,
            entity_key="concept:pm25",
            entity_type="concept",
            canonical_name="PM2.5",
        )
        assert ep.entity_id == eid
        assert ep.entity_key == "concept:pm25"

    def test_optional_fields_can_be_none(self) -> None:
        from llamaindex_runtime.graph.projector import EntityProjection

        ep = EntityProjection(
            entity_id=uuid.uuid4(),
            entity_key="concept:unknown",
            entity_type=None,
            canonical_name=None,
        )
        assert ep.entity_type is None
        assert ep.canonical_name is None


class TestRelationProjectionContract:
    """RelationProjection frozen dataclass: required fields, immutability."""

    def test_frozen_dataclass(self) -> None:
        from llamaindex_runtime.graph.projector import RelationProjection

        rp = RelationProjection(
            relation_id=uuid.uuid4(),
            relation_type="affects",
            source_entity_id=uuid.uuid4(),
            target_entity_id=uuid.uuid4(),
        )
        with pytest.raises(AttributeError):
            rp.relation_type = "modified"  # type: ignore[misc]

    def test_required_fields(self) -> None:
        from llamaindex_runtime.graph.projector import RelationProjection

        src = uuid.uuid4()
        tgt = uuid.uuid4()
        rid = uuid.uuid4()
        rp = RelationProjection(
            relation_id=rid,
            relation_type="affects",
            source_entity_id=src,
            target_entity_id=tgt,
        )
        assert rp.relation_id == rid
        assert rp.relation_type == "affects"
        assert rp.source_entity_id == src
        assert rp.target_entity_id == tgt


class TestEvidenceLinkProjectionContract:
    """EvidenceLinkProjection frozen dataclass: span_id anchor, entity_id or relation_id."""

    def test_frozen_dataclass(self) -> None:
        from llamaindex_runtime.graph.projector import EvidenceLinkProjection

        elp = EvidenceLinkProjection(
            entity_id=uuid.uuid4(),
            relation_id=None,
            version_id=uuid.uuid4(),
            span_id=uuid.uuid4(),
            confidence_score=0.9,
        )
        with pytest.raises(AttributeError):
            elp.confidence_score = 0.5  # type: ignore[misc]

    def test_span_id_field_exists(self) -> None:
        """EvidenceLinkProjection must have span_id (not chunk_id)."""
        from llamaindex_runtime.graph.projector import EvidenceLinkProjection

        elp = EvidenceLinkProjection(
            entity_id=uuid.uuid4(),
            relation_id=None,
            version_id=uuid.uuid4(),
            span_id=uuid.uuid4(),
            confidence_score=None,
        )
        assert hasattr(elp, "span_id")
        assert not hasattr(elp, "chunk_id"), (
            "EvidenceLinkProjection must not have chunk_id field; evidence anchors on span_id"
        )

    def test_entity_id_or_relation_id(self) -> None:
        """EvidenceLinkProjection supports both entity_id and relation_id anchors."""
        from llamaindex_runtime.graph.projector import EvidenceLinkProjection

        # Entity-anchored
        elp_entity = EvidenceLinkProjection(
            entity_id=uuid.uuid4(),
            relation_id=None,
            version_id=uuid.uuid4(),
            span_id=uuid.uuid4(),
            confidence_score=None,
        )
        assert elp_entity.entity_id is not None

        # Relation-anchored
        elp_rel = EvidenceLinkProjection(
            entity_id=None,
            relation_id=uuid.uuid4(),
            version_id=uuid.uuid4(),
            span_id=uuid.uuid4(),
            confidence_score=None,
        )
        assert elp_rel.relation_id is not None

    def test_confidence_score_optional(self) -> None:
        from llamaindex_runtime.graph.projector import EvidenceLinkProjection

        elp = EvidenceLinkProjection(
            entity_id=uuid.uuid4(),
            relation_id=None,
            version_id=uuid.uuid4(),
            span_id=uuid.uuid4(),
            confidence_score=None,
        )
        assert elp.confidence_score is None

    def test_entity_id_or_relation_id_required(self) -> None:
        from llamaindex_runtime.graph.projector import EvidenceLinkProjection

        with pytest.raises(ValueError, match="entity_id or relation_id"):
            EvidenceLinkProjection(
                entity_id=None,
                relation_id=None,
                version_id=uuid.uuid4(),
                span_id=uuid.uuid4(),
                confidence_score=None,
            )


# ===========================================================================
# UNIT TESTS -- GraphProjector (mocked Neo4j driver)
# ===========================================================================


class TestGraphProjectorProjectEntity:
    """GraphProjector.project_entity issues correct Cypher."""

    def test_issues_merge_entity_cypher(self) -> None:
        from llamaindex_runtime.graph.projector import EntityProjection, GraphProjector

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        entity_id = uuid.uuid4()
        projector.project_entity(
            EntityProjection(
                entity_id=entity_id,
                entity_key="concept:pm25",
                entity_type="concept",
                canonical_name="PM2.5",
            )
        )

        session.run.assert_called_once()
        cypher, kwargs = session.run.call_args[0][0], session.run.call_args[1]
        assert "MERGE" in cypher
        assert "Entity" in cypher
        assert kwargs["entity_id"] == str(entity_id)
        assert kwargs["entity_key"] == "concept:pm25"
        assert kwargs["entity_type"] == "concept"
        assert kwargs["canonical_name"] == "PM2.5"

    def test_null_optional_fields_pass_through(self) -> None:
        from llamaindex_runtime.graph.projector import EntityProjection, GraphProjector

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        projector.project_entity(
            EntityProjection(
                entity_id=uuid.uuid4(),
                entity_key="concept:unknown",
                entity_type=None,
                canonical_name=None,
            )
        )

        _, kwargs = session.run.call_args
        assert kwargs["entity_type"] is None
        assert kwargs["canonical_name"] is None


class TestGraphProjectorProjectRelation:
    """GraphProjector.project_relation issues correct Cypher."""

    def test_issues_match_merge_relation_cypher(self) -> None:
        from llamaindex_runtime.graph.projector import GraphProjector, RelationProjection

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        src = uuid.uuid4()
        tgt = uuid.uuid4()
        rid = uuid.uuid4()
        projector.project_relation(
            RelationProjection(
                relation_id=rid,
                relation_type="affects",
                source_entity_id=src,
                target_entity_id=tgt,
            )
        )

        session.run.assert_called_once()
        cypher, kwargs = session.run.call_args[0][0], session.run.call_args[1]
        assert "MATCH" in cypher
        assert "MERGE" in cypher
        assert "RELATION" in cypher
        assert kwargs["relation_id"] == str(rid)
        assert kwargs["relation_type"] == "affects"
        assert kwargs["source_entity_id"] == str(src)
        assert kwargs["target_entity_id"] == str(tgt)


class TestGraphProjectorProjectEvidenceLink:
    """GraphProjector.project_evidence_link issues correct Cypher with span_id."""

    def test_entity_evidence_link_cypher(self) -> None:
        from llamaindex_runtime.graph.projector import EvidenceLinkProjection, GraphProjector

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        entity_id = uuid.uuid4()
        version_id = uuid.uuid4()
        span_id = uuid.uuid4()
        projector.project_evidence_link(
            EvidenceLinkProjection(
                entity_id=entity_id,
                relation_id=None,
                version_id=version_id,
                span_id=span_id,
                confidence_score=0.85,
            )
        )

        session.run.assert_called_once()
        cypher, kwargs = session.run.call_args[0][0], session.run.call_args[1]
        assert "SUPPORTED_BY" in cypher
        assert "span_id" in cypher
        assert kwargs["span_id"] == str(span_id)
        assert kwargs["entity_id"] == str(entity_id)
        assert kwargs["version_id"] == str(version_id)
        assert abs(kwargs["confidence_score"] - 0.85) < 1e-6

    def test_relation_evidence_link_cypher(self) -> None:
        """Evidence link on a relation must use the relation as the source node."""
        from llamaindex_runtime.graph.projector import EvidenceLinkProjection, GraphProjector

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        rel_id = uuid.uuid4()
        version_id = uuid.uuid4()
        span_id = uuid.uuid4()
        projector.project_evidence_link(
            EvidenceLinkProjection(
                entity_id=None,
                relation_id=rel_id,
                version_id=version_id,
                span_id=span_id,
                confidence_score=None,
            )
        )

        session.run.assert_called_once()
        cypher, kwargs = session.run.call_args[0][0], session.run.call_args[1]
        assert "SUPPORTED_BY" in cypher
        assert kwargs["span_id"] == str(span_id)
        assert kwargs["relation_id"] == str(rel_id)
        assert kwargs["confidence_score"] is None

    def test_null_confidence_score_passes_through(self) -> None:
        from llamaindex_runtime.graph.projector import EvidenceLinkProjection, GraphProjector

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        projector.project_evidence_link(
            EvidenceLinkProjection(
                entity_id=uuid.uuid4(),
                relation_id=None,
                version_id=uuid.uuid4(),
                span_id=uuid.uuid4(),
                confidence_score=None,
            )
        )

        _, kwargs = session.run.call_args
        assert kwargs["confidence_score"] is None


# ===========================================================================
# UNIT TESTS -- project_version_to_graph (high-level orchestration)
# ===========================================================================


class TestProjectVersionToGraph:
    """project_version_to_graph reads from RegistryWriter and projects all KG data."""

    def test_projects_entities_relations_and_evidence_links(self) -> None:
        from llamaindex_runtime.graph.projector import (
            GraphProjector,
            project_version_to_graph,
        )

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        e1 = uuid.uuid4()
        e2 = uuid.uuid4()
        rel_id = uuid.uuid4()
        span_id = uuid.uuid4()
        version_id = uuid.uuid4()

        registry = MagicMock()
        registry.query_entities.return_value = [
            {"entity_id": e1, "entity_key": "concept:pm25", "entity_type": "concept", "canonical_name": "PM2.5"},
            {"entity_id": e2, "entity_key": "concept:aqi", "entity_type": "concept", "canonical_name": "AQI"},
        ]
        registry.query_relations.return_value = [
            {
                "relation_id": rel_id,
                "relation_key": "pm25-affects-aqi",
                "relation_type": "affects",
                "source_entity_id": e1,
                "target_entity_id": e2,
            },
        ]
        registry.query_evidence_links_by_version.return_value = [
            {
                "evidence_link_id": uuid.uuid4(),
                "version_id": version_id,
                "entity_id": e1,
                "relation_id": None,
                "span_id": span_id,
                "source_kind": "ner",
                "confidence_score": 0.9,
            },
        ]

        project_version_to_graph(registry, projector, version_id=version_id)

        # 2 entities + 1 relation + 1 evidence link = 4 Cypher calls
        assert session.run.call_count == 4

    def test_queries_registry_with_correct_version_id(self) -> None:
        from llamaindex_runtime.graph.projector import (
            GraphProjector,
            project_version_to_graph,
        )

        driver, _session = _make_mock_driver()
        projector = GraphProjector(driver)
        version_id = uuid.uuid4()

        registry = MagicMock()
        registry.query_entities.return_value = []
        registry.query_relations.return_value = []
        registry.query_evidence_links_by_version.return_value = []

        project_version_to_graph(registry, projector, version_id=version_id)

        registry.query_evidence_links_by_version.assert_called_once_with(version_id)

    def test_empty_registry_is_noop(self) -> None:
        from llamaindex_runtime.graph.projector import (
            GraphProjector,
            project_version_to_graph,
        )

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        registry = MagicMock()
        registry.query_entities.return_value = []
        registry.query_relations.return_value = []
        registry.query_evidence_links_by_version.return_value = []

        project_version_to_graph(registry, projector, version_id=uuid.uuid4())

        session.run.assert_not_called()

    def test_evidence_link_on_relation_is_projected(self) -> None:
        """Evidence links anchored on relation_id must also be projected."""
        from llamaindex_runtime.graph.projector import (
            GraphProjector,
            project_version_to_graph,
        )

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        e1 = uuid.uuid4()
        e2 = uuid.uuid4()
        rel_id = uuid.uuid4()
        span_id = uuid.uuid4()
        version_id = uuid.uuid4()

        registry = MagicMock()
        registry.query_entities.return_value = [
            {"entity_id": e1, "entity_key": "concept:a", "entity_type": "concept", "canonical_name": "A"},
            {"entity_id": e2, "entity_key": "concept:b", "entity_type": "concept", "canonical_name": "B"},
        ]
        registry.query_relations.return_value = [
            {
                "relation_id": rel_id,
                "relation_key": "a-relates-b",
                "relation_type": "relates_to",
                "source_entity_id": e1,
                "target_entity_id": e2,
            },
        ]
        registry.query_evidence_links_by_version.return_value = [
            {
                "evidence_link_id": uuid.uuid4(),
                "version_id": version_id,
                "entity_id": None,
                "relation_id": rel_id,
                "span_id": span_id,
                "source_kind": "manual",
                "confidence_score": None,
            },
        ]

        project_version_to_graph(registry, projector, version_id=version_id)

        # 2 entities + 1 relation + 1 evidence link = 4 Cypher calls
        assert session.run.call_count == 4

    def test_entities_projected_before_relations(self) -> None:
        """Entities must be projected before relations (relations MATCH on entities)."""
        from llamaindex_runtime.graph.projector import (
            GraphProjector,
            project_version_to_graph,
        )

        driver, session = _make_mock_driver()
        projector = GraphProjector(driver)

        e1 = uuid.uuid4()
        e2 = uuid.uuid4()
        rel_id = uuid.uuid4()

        registry = MagicMock()
        registry.query_entities.return_value = [
            {"entity_id": e1, "entity_key": "concept:a", "entity_type": "concept", "canonical_name": "A"},
        ]
        registry.query_relations.return_value = [
            {
                "relation_id": rel_id,
                "relation_key": "a-relates-b",
                "relation_type": "relates_to",
                "source_entity_id": e1,
                "target_entity_id": e2,
            },
        ]
        registry.query_evidence_links_by_version.return_value = []

        project_version_to_graph(registry, projector, version_id=uuid.uuid4())

        # Verify order: entity Cypher first, then relation Cypher
        calls = session.run.call_args_list
        assert len(calls) == 2
        first_cypher = calls[0][0][0]
        second_cypher = calls[1][0][0]
        assert "Entity" in first_cypher and "MERGE" in first_cypher
        assert "RELATION" in second_cypher


# ===========================================================================
# UNIT TESTS -- GraphRuntimeSeam integration with GraphProjector
# ===========================================================================


class TestGraphRuntimeSeamProjector:
    """GraphRuntimeSeam should be usable to create a GraphProjector."""

    def test_seam_has_create_projector_method(self) -> None:
        from llamaindex_runtime.graph.seam import GraphRuntimeSeam

        assert hasattr(GraphRuntimeSeam, "create_projector"), (
            "GraphRuntimeSeam must have a create_projector method"
        )

    def test_create_projector_returns_graph_projector(self) -> None:
        from llamaindex_runtime.graph.projector import GraphProjector
        from llamaindex_runtime.graph.seam import GraphRuntimeSeam

        seam = GraphRuntimeSeam(
            property_graph_index_class=type("FakePGI", (), {}),
            graph_store_class=type("FakeNeo4j", (), {}),
        )
        driver = MagicMock()
        projector = seam.create_projector(driver)
        assert isinstance(projector, GraphProjector)
