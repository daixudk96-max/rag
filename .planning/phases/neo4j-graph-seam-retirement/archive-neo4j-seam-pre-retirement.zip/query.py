"""Graph retrieval path over persisted KG data from Phase 5.

Queries entity neighbors via Neo4j driver, mapping graph nodes to
QueryHit objects for integration with the unified query entrypoint.

Scope: narrow slice - entity neighbor traversal only, no deep hybrid.
"""
from __future__ import annotations

from types import MappingProxyType
from typing import Any
from uuid import UUID

from llamaindex_runtime.entrypoints.types import QueryHit


def retrieve_graph_hits(
    driver: Any,
    entity_id: UUID,
    *,
    depth: int = 1,
) -> list[QueryHit]:
    """Retrieve entity neighbors from Neo4j graph and return QueryHit objects.

    Parameters
    ----------
    driver:
        A Neo4j driver instance. Must not be None.
    entity_id:
        UUID of the source entity to query neighbors for. Must not be None.
    depth:
        Traversal depth (1 = direct neighbors, 2 = neighbors of neighbors).
        Must be >= 1. Defaults to 1.

    Returns
    -------
    list[QueryHit]
        Graph neighbor hits with canonical_name as text, entity metadata,
        and None score (graph queries have no similarity scoring).

    Raises
    ------
    ValueError
        If driver is None, entity_id is None, or depth < 1.
    """
    if driver is None:
        raise ValueError("driver is required for graph mode")
    if entity_id is None:
        raise ValueError("entity_id is required for graph mode")
    if depth < 1:
        raise ValueError("depth must be >= 1")

    # Query neighbors based on depth
    if depth == 1:
        cypher = (
            "MATCH (e:Entity {entity_id: $entity_id})-[r:RELATION]->(t:Entity) "
            "RETURN t.entity_id AS entity_id, t.entity_key AS entity_key, "
            "r.relation_type AS relation_type, t.canonical_name AS canonical_name, "
            "t.entity_type AS entity_type"
        )
    else:
        # For depth > 1, extend traversal (minimal implementation for now)
        cypher = (
            f"MATCH (e:Entity {{entity_id: $entity_id}})-[r:RELATION*1..{depth}]->(t:Entity) "
            "RETURN t.entity_id AS entity_id, t.entity_key AS entity_key, "
            "r.relation_type AS relation_type, t.canonical_name AS canonical_name, "
            "t.entity_type AS entity_type"
        )

    with driver.session() as session:
        result = session.run(cypher, entity_id=str(entity_id))
        rows = result.data()

    hits: list[QueryHit] = []
    for row in rows:
        metadata: dict[str, Any] = {
            "entity_id": UUID(row["entity_id"]),
            "entity_key": row["entity_key"],
            "relation_type": row["relation_type"],
            "entity_type": row.get("entity_type"),
        }

        # Use canonical_name as text (entity's human-readable name)
        text = row.get("canonical_name") or row["entity_key"]

        hits.append(
            QueryHit(
                text=text,
                score=None,  # Graph queries don't have similarity scores
                metadata=MappingProxyType(metadata),
            )
        )

    return hits